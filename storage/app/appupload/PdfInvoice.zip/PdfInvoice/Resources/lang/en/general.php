<?php

return [

    'name'              => 'PdfInvoice',
    'description'       => 'This is my awesome module',

];